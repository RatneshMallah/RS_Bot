from itertools import groupby
import win32com.client as win32

import argparse
import sys
import json
import os
from docx import Document
from docx import *



def get_headings(filea):
    document = Document(filea)
    bolds=[]
    italics=[]
    for para in document.paragraphs:
        for run in para.runs:
            if run.italic :
                italics.append(run.text)
            if run.bold :
                bolds.append(run.text)
    return bolds,filea


def update_json(a_dict,fileb):
    #a_dict = {'new_key': 'new_value'}
    with open(fileb) as f:
        data = json.load(f)

    data.append(a_dict)
    with open(fileb, 'w') as f:
        json.dump(data, f)


def train(files):
    json_file = os.path.join(os.getcwd(),"data.json")
    for f in files:
        hd = get_headings(f)
        for j in hd[0]:
            a_dict = {"MESSAGE":j,
                        "RESPONSE" : "You can refer {}".format(hd[1])}
            
            update_json(a_dict, json_file)


parser = argparse.ArgumentParser("TrainDoc")
parser.add_argument("-a","--all",help="Train all docs from current directory",default=None)
parser.add_argument("-f","--file",help="Train word doc file",default=None)

args = parser.parse_args()

files = []
json_file = os.path.join(os.getcwd(),"data.json")

if args.file is not None:
    file_path = args.file
    if os.path.isfile(file_path):
        files.append(file_path)
    else:
        print("File not present : ",file_path)
        sys.exit()


if args.all is not None:
    docx_path = args.all
    files = os.listdir(docx_path)
    if len(files) !=0:
        for file in files:
            if file.split(".")[-1] == "docx":
                files.append(file)


# {
#     "MESSAGE": " rkm",
#     "RESPONSE": "hi"
#   }


# fileP = os.path.join(os.getcwd(),"Docs","carInsurance.docx")

# All the same as yours
# def get_headings(file):
#     word = win32.Dispatch("Word.Application")
#     word.Visible = 0
#     word.Documents.Open(file)
#     doc = word.ActiveDocument
#     for heading, grp_wrds in groupby(doc.Words, key=lambda x: str(x.Style)):
#         print(heading, ''.join(str(word) for word in grp_wrds))


if args.file is None and args.all is None:
    print("Please choose options\nFor help : python train_doc.py --help")
else:
    train(files)


