import nltk
from deeppavlov import build_model, configs
nltk.download('stopwords')
nltk.download('punkt')
nltk.download('wordnet')

model_fa = build_model(configs.squad.multi_squad_noans, download=True)
model_qa = build_model(configs.squad.squad, download=True)