from itertools import groupby
import win32com.client as win32

import argparse
import sys

parser = argparse.ArgumentParser("TrainDoc")
parser.add_argument("-a","--all",help="Train all docs from current directory",default=None)
parser.add_argument("-f","--file",help="Train word doc file",default=None)

args = parser.parse_args()

if args.file is not None:
    file_path = os.path.join(os.getcwd(),args.file)
    if os.path.isfile(file_path):
        add_data(data.json)



# All the same as yours
def get_headings(file):
    word = win32.Dispatch("Word.Application")
    word.Visible = 0
    word.Documents.Open(file)
    doc = word.ActiveDocument
    for heading, grp_wrds in groupby(doc.Words, key=lambda x: str(x.Style)):
        print(heading, ''.join(str(word) for word in grp_wrds))