from deeppavlov import build_model, configs
import os
import sys

model_qa = build_model(configs.squad.squad, download=False)
model_fa = build_model(configs.squad.multi_squad_noans, download=False)

# model_qa(["In meteorology, precipitation is any product of the condensation of atmospheric water vapor \
#          that falls under gravity. The main forms of precipitation include drizzle, rain, sleet, snow, \
#          graupel and hail. Precipitation forms as smaller droplets coalesce via collision with other rain drops \
#          or ice crystals within a cloud. Short, intense periods of rain in scattered locations are called showers."],
#          ["Where do water droplets collide with ice crystals to form precipitation?"])

#context_en = "Cognizant is an American multinational corporation that provides IT services, including digital, technology, consulting, and operations services. It is headquartered in Teaneck, New Jersey, United States. Cognizant is part of the NASDAQ-100 and trades under CTSH. It was founded as an in-house technology unit of Dun & Bradstreet in 1994,[4] and started serving external clients in 1996.[4]"

def open_context_en(file):
    if os.path.isfile(file):
        content = open(file).read()
        return content
    else:
        print("No such file or directory")
        sys.exit()


mc = open_context_en("context.txt")
# model_qa_ml = build_model(configs.squad.squad_bert_multilingual_freezed_emb, download=True) 
# model_qa_ml([context_en, context_fr, context_fr], 
#       ["Where do water droplets collide with ice crystals to form precipitation?",
#        "Sous quelle forme peut être précipitation?",
#        "Where the term precipitation can be used?"])

# print(model_qa([context_en],["Where do water droplets collide with ice crystals to form precipitation?"]),"----")
# print(model_fa([context_en],["Where do water droplets collide with ice crystals to form precipitation?"]),"----")

#print(model_qa([mc],["When codnizant founded"]))
# def ask_bert(query):
#     threshold = model_fa([mc],[query])[2][0]
#     if threshold >= 0.7:
#         return str(model_qa([mc],[query])[0][0])+str(threshold)
#     else:
#         return "bert : I didn't get you"


def ask_bert(query):
    res = model_fa([mc],[query])[0][0]
    if res != "":
        return res
    else :
        return "I didn't get you"

"""
Kumar Mahadeva decided to reduce the company's dependence on Y2K projects: by Q1 1999, 26% of company's revenues came from Y2K projects, compared with 49% in early 1998. Believing that the $16.6 billion enterprise resource planning software market was saturated, Kumar Mahadeva decided to refrain from large-scale ERP implementation projects. Instead, he focused on applications management, which accounted for 37% of Cognizant's revenue in Q1 1999.[8] Cognizant's revenues in 2002 were $229 million, and the company had zero debt with $100 million in the bank.[12] During the dotcom bust, the company grew by taking on the maintenance projects that larger IT services companies did not want.
In 2003, IMS Health sold its entire 56% stake in Cognizant, which instituted a poison pill provision to prevent hostile takeover attempts.[12][14] Kumar Mahadeva resigned as the CEO in 2003, and was replaced by Lakshmi Narayanan.[15] Gradually, the company's services portfolio expanded across the IT services landscape and into business process outsourcing (BPO) and business consulting. Lakshmi Narayanan was succeeded by Frank D'souza in 2006. Cognizant experienced a period of fast growth during the 2000s, as reflected by its appearance in Fortune magazine's "100 Fastest-Growing Companies" list for ten consecutive years from 2003 to 2012.[16][17]
"""

# from deeppavlov import build_model, configs

# model = build_model(configs.squad.squad, download=True)
# model(['DeepPavlov is library for NLP and dialog systems.'], ['What is DeepPavlov?'])