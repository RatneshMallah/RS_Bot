import nltk
from nltk.stem.lancaster import LancasterStemmer
stemmer = LancasterStemmer()

import numpy
import tflearn
import tensorflow
import random
import json
import argparse
import sys
#nltk.download('punkt')

parser = argparse.ArgumentParser("RKM")
parser.add_argument("-t","--train",help="Choose option to train model Ex : -t y",default=None)
parser.add_argument("-f","--file",help="Give training JSON datasheet",default="intents.json")

args = parser.parse_args()

try:
	with open(args.file) as file:
		data = json.load(file)
except:
	print("loading json file Error")
	sys.exit()


words,labels,docs_x,docs_y = [],[],[],[]

for intent in data['intents']:
	for pattern in intent['patterns']:
		wrds = nltk.word_tokenize(pattern) 
		words.extend(wrds)
		docs_x.append(wrds)
		docs_y.append(intent["tag"])
		if intent['tag'] not in labels:
			labels.append(intent['tag'])



# print("words : ",words)

words = [stemmer.stem(w.lower()) for w in words if w != "?"]
words = sorted(list(set(words)))
# print("words : ",words)
# print("labels : ",labels)
# print("docs_x : ",docs_x)
labels = sorted(labels)

training = []
output = []

out_empty = [0 for _ in range(len(labels))]

for x, doc in enumerate(docs_x):
    bag = []
    wrds = [stemmer.stem(w.lower()) for w in doc]
    for w in words:
        if w in wrds:
            bag.append(1)
        else:
            bag.append(0)
    output_row = out_empty[:]
    output_row[labels.index(docs_y[x])] = 1
    training.append(bag)
    output.append(output_row)


training = numpy.array(training)
output = numpy.array(output)
# print("Trining : ",training)
# print("Output : ",output)

tensorflow.reset_default_graph()

net = tflearn.input_data(shape=[None,len(training[0])])
net= tflearn.fully_connected(net, 8)
net= tflearn.fully_connected(net, 8)
net= tflearn.fully_connected(net, len(output[0]),activation="softmax")
net= tflearn.regression(net)

model = tflearn.DNN(net)

if not args.train:
	try:
		print("model loading")
		model.load("model.tflearn")
		print("Loaded")
	except:
		print("calling----")
		model.fit(training, output, n_epoch=1000, batch_size=8, show_metric=True)
		model.save("model.tflearn")
else:
	model.fit(training, output, n_epoch=1000, batch_size=8, show_metric=True)
	model.save("model.tflearn")

def bag_of_words(s, word):
	bag = [0 for _ in range(len(words))]
	s_words = nltk.word_tokenize(s)
	s_words = [stemmer.stem(word.lower()) for word in s_words]
	for se in s_words:
		for i, w in enumerate(words):
			if w == se:
				bag[i] = 1
	return numpy.array(bag)


def chat():
	print("Start with the bot (type quit to exit)")
	while True:
		inp = input("You : ")
		if inp.lower() == "quit":
			break
		results = model.predict([bag_of_words(inp, words)])[0]
		results_index = numpy.argmax(results)
		tag = labels[results_index]
		if results[results_index] > 0.8:
			for tg in data["intents"]:
				if tg['tag'] == tag:
					responses = tg["responses"]
			print(random.choice(responses))
		else:
			print("I didn't get that, try again.")


def get_response(query):
	results = model.predict([bag_of_words(query, words)])[0]
	results_index = numpy.argmax(results)
	tag = labels[results_index]
	if results[results_index] > 0.8:
		for tg in data["intents"]:
			if tg['tag'] == tag:
				responses = tg["responses"]
		return str(random.choice(responses))+"\n"+"Eff : "+str(results[results_index])
	else:
		return "I didn't get that, try again."+"\n"+"Eff : "+str(results[results_index])



#chat()